package com.webtech.registrationform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondPage extends AppCompatActivity {

    TextView tv_firstname,tv_lastname,tv_gender,tv_city,tv_hobbies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);

        tv_firstname = findViewById(R.id.tv_firstname);
        tv_lastname = findViewById(R.id.tv_lastname);
        tv_gender = findViewById(R.id.tv_gender);
        tv_city = findViewById(R.id.tv_city);
        tv_hobbies = findViewById(R.id.tv_hobbies);

        Intent i = getIntent();
        if(i.getBundleExtra("data")!=null){
            Bundle bundle = i.getBundleExtra("data");

            tv_firstname.setText(bundle.getString("firstname"));
            tv_lastname.setText(bundle.getString("lastname"));
            tv_gender.setText(bundle.getString("gender"));
            tv_city.setText(bundle.getString("city"));
            tv_hobbies.setText(bundle.getString("hobbies"));
        }
    }
}
