package com.webtech.demo1;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class SecondPage extends AppCompatActivity {

    RecyclerView rv;
    Context c;
    TextView tvtotal;
    Button btnsubmit;
    int total = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_page);


        rv = findViewById(R.id.rv);
        tvtotal = findViewById(R.id.tvtotal);
        btnsubmit = findViewById(R.id.btnsubmit);
        c = SecondPage.this;

        Intent i = getIntent();
        if(!i.getStringExtra("name").equals("")){
            String name = i.getStringExtra("name");
            String[] arname = name.split(", ");


            Custom adapter = new Custom(arname);
            RecyclerView.LayoutManager lm = new LinearLayoutManager(c);
            rv.setLayoutManager(lm);
            rv.setAdapter(adapter);

            btnsubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });


            Log.d("==MSG==","Total Array is: "+arname.length);
        }
    }

    class Custom extends RecyclerView.Adapter<Custom.Viewholder>{
        String[] arname;

        Custom(String[] arname){
            this.arname = arname;
        }

        class Viewholder extends RecyclerView.ViewHolder{
            TextView tvtitle;
            EditText edt1;

            public Viewholder(@NonNull View v) {
                super(v);

                tvtitle = v.findViewById(R.id.tv1);
                edt1 = v.findViewById(R.id.edt1);

                edt1.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                        total += Integer.parseInt(editable.toString());
                        tvtotal.setText(""+total);
                    }
                });
            }
        }

        @NonNull
        @Override
        public Custom.Viewholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(c).inflate(R.layout.singleitem,viewGroup,false);
            return new Viewholder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Custom.Viewholder holder, int i) {
            holder.tvtitle.setText(arname[i]);
        }

        @Override
        public int getItemCount() {
            return arname.length;
        }
    }
}
