package com.webtech.demo1;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    Context c;
    Button btn1;
    MultiAutoCompleteTextView matv1;
    String[] data = {
            "Rajkot","Surat","Vadodara","Jamnagar","Delhi","Ahmedabad","Gandhinagar"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c = MainActivity.this;
        matv1 = findViewById(R.id.matv1);
        btn1 = findViewById(R.id.btn1);

        ArrayAdapter adapter = new ArrayAdapter(c,android.R.layout.simple_list_item_1,data);
        matv1.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        matv1.setAdapter(adapter);
        matv1.setThreshold(1);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent i = new Intent(c,SecondPage.class);
               i.putExtra("name",matv1.getText().toString());
               startActivity(i);
            }
        });
    }
}
