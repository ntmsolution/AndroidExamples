package com.webtech;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edt1,edt2,edt3;
    Button btn;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edt1 = findViewById(R.id.edt1);
        edt2 = findViewById(R.id.edt2);
        edt3 = findViewById(R.id.edt3);
        btn = findViewById(R.id.btn);

        context = MainActivity.this;

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = edt1.getText().toString() +"\n"+
                        edt2.getText().toString() +"\n"+
                        edt3.getText().toString();

                Toast.makeText(context,"Name : " + msg,Toast.LENGTH_SHORT).show();
            }
        });


    }
}

