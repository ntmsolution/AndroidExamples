package com.webtech.customgridview;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.GridView;

public class MainActivity extends AppCompatActivity {

    Context c;
    GridView gv;
    String[] titles = {
      "Image - 1",
      "Image - 2",
      "Image - 3",
      "Image - 4",
      "Image - 5",
      "Image - 6"
    };
    int[] images = {
        R.drawable.img1,
        R.drawable.img2,
        R.drawable.img3,
        R.drawable.img4,
        R.drawable.img5,
        R.drawable.img6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c = MainActivity.this;
        gv = findViewById(R.id.gv);

        Custom adapter = new Custom(c,images,titles);
        gv.setAdapter(adapter);
    }

}
