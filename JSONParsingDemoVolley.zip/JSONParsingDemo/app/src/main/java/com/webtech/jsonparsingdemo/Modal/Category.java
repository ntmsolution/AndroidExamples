package com.webtech.jsonparsingdemo.Modal;

public class Category {
    public String id,categoryname;

    public Category(String id,String categoryname){
            this.id = id;
            this.categoryname = categoryname;
    }
}
