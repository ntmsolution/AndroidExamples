package com.webtech.customadapterdemo;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Context context;
    ListView lv;
    int[] images = {
      R.drawable.rajkot,
      R.drawable.surat,
      R.drawable.delhi,
      R.drawable.gandhinagar,
      R.drawable.agra,
      R.drawable.ajmer,
      R.drawable.jaipur
    };
    String[] title = {"Rajkot","Surat","Delhi","Gandhinagar","Agra","Ajmer","Jaipur"};
    String[] phone = {"0281 - 2232655","022-04541214","035 - 45454444","145 - 145751","231 - 5232232","556 - 256234456","585 - 598989223"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lv = findViewById(R.id.lv);
        context = MainActivity.this;

        Custom adapter = new Custom();
        lv.setAdapter(adapter);
    }

    class Custom extends BaseAdapter{

        @Override
        public int getCount() {
            return title.length;// Specify howmany times repeat this loop
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            view = LayoutInflater.from(context).inflate(R.layout.single_layout,viewGroup,false);

            TextView tvtitle = view.findViewById(R.id.tvtitle);
            TextView tvphone = view.findViewById(R.id.tvphone);
            ImageView img= view.findViewById(R.id.img1);

            tvtitle.setText(title[i]);
            tvphone.setText(phone[i]);
            img.setImageResource(images[i]);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context)
                            .setTitle("Make a call?")
                            .setMessage("On "+phone[i])
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                }
                            });
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();


                }
            });

            return view;
        }
    }
}
