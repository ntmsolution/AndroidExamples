package com.webtech.registrationform;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Context c;
    EditText edt_firstname, edt_lastname;
    RadioGroup rdo_gender;
    Spinner spn_city;
    CheckBox chk_cricket, chk_hockey, chk_football, chk_chess;
    Button btnsubmit;
    String TAG = "=ERROR=";
    String[] ar_city = {"","Rajkot", "Ahmedabad", "Surat", "Vadodara", "Jamanagar", "Gandhinagar"};

    TextView tv_firstname, tv_lastname, tv_gender, tv_city, tv_hobbies;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c = MainActivity.this;
        edt_firstname = findViewById(R.id.edt_firstname);
        edt_lastname = findViewById(R.id.edt_lastname);
        rdo_gender = findViewById(R.id.rdo_gender);
        spn_city = findViewById(R.id.spn_city);
        chk_cricket = findViewById(R.id.chk_cricket);
        chk_hockey = findViewById(R.id.chk_hockey);
        chk_football = findViewById(R.id.chk_football);
        chk_chess = findViewById(R.id.chk_chess);
        btnsubmit = findViewById(R.id.btnsubmit);

        tv_firstname = findViewById(R.id.tv_firstname);
        tv_lastname = findViewById(R.id.tv_lastname);
        tv_gender = findViewById(R.id.tv_gender);
        tv_city = findViewById(R.id.tv_city);
        tv_hobbies = findViewById(R.id.tv_hobbies);

        // Initializa the city array to spinner
        ArrayAdapter adapter = new ArrayAdapter(c, android.R.layout.simple_list_item_1, ar_city);
        spn_city.setAdapter(adapter);


        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (validateform()) {
                    try {

                        String firstname, lastname, gender, city, hobbies;

                        firstname = edt_firstname.getText().toString();
                        lastname = edt_lastname.getText().toString();

                        RadioButton checkedgender = (RadioButton) findViewById(rdo_gender.getCheckedRadioButtonId());
                        gender = checkedgender.getText().toString();

                        city = spn_city.getSelectedItem().toString();
                        String temp_hobbies = "";

                        if (chk_cricket.isChecked()) {
                            temp_hobbies = "Cricket";
                        }
                        if (chk_hockey.isChecked()) {
                            if (!temp_hobbies.equals("")) {
                                temp_hobbies += ", Hockey";
                            } else {
                                temp_hobbies = "Hockey";
                            }
                        }
                        if (chk_football.isChecked()) {
                            if (!temp_hobbies.equals("")) {
                                temp_hobbies += ", Football";
                            } else {
                                temp_hobbies = "Football";
                            }
                        }
                        if (chk_chess.isChecked()) {
                            if (!temp_hobbies.equals("")) {
                                temp_hobbies += ", Chess";
                            } else {
                                temp_hobbies = "Chess";
                            }
                        }

                        hobbies = temp_hobbies;

                        String msg = "First Name = " + firstname + "\n" +
                                "Last Name = " + lastname + "\n" +
                                "Gender = " + gender + "\n" +
                                "City = " + city + "\n" +
                                "Hobbies = " + hobbies;


                        Intent i = new Intent(c, SecondPage.class);

                        Bundle bundle = new Bundle();
                        bundle.putString("firstname", firstname);
                        bundle.putString("lastname", lastname);
                        bundle.putString("gender", gender);
                        bundle.putString("city", city);
                        bundle.putString("hobbies", hobbies);


                        i.putExtra("data", bundle);
                        startActivity(i);
                   /*
                    i.putExtra("firstname",firstname);
                    i.putExtra("lastname",lastname);
                    i.putExtra("gender",gender);
                    i.putExtra("city",city);
                    i.putExtra("hobbies",hobbies);*/


                        Toast.makeText(c, msg, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Log.e(TAG, "Error in: " + e);
                    }
                }
            }
        });


    }

    boolean validateform() {

            /*
        EditText edt_firstname,edt_lastname;
        RadioGroup rdo_gender;
        Spinner spn_city;
        CheckBox chk_cricket,chk_hockey,chk_football,chk_chess;
        Button btnsubmit;
        */
        Boolean flg = true;

        if (edt_firstname.getText().toString().length() == 0) {
            tv_firstname.setText("Please enter firstname");
            edt_firstname.requestFocus();
            flg = false;
        }else{
            tv_firstname.setText("");
        }

        if (edt_lastname.getText().toString().length() == 0) {
            tv_lastname.setText("Please enter lastname");
            edt_lastname.requestFocus();
            flg = false;
        }else{
            tv_lastname.setText("");
        }

        if (rdo_gender.getCheckedRadioButtonId() == -1) {
            tv_gender.setText("Please select gender");

            flg = false;
        }else{
            tv_gender.setText("");
        }

        if (spn_city.getSelectedItem().toString().length() == 0) {
            tv_city.setText("Please select city");
            spn_city.requestFocus();
            flg = false;
        }else{
            tv_city.setText("");
        }

        if (chk_cricket.isChecked() == false && chk_hockey.isChecked() == false && chk_chess.isChecked() == false && chk_football.isChecked() == false) {
            tv_hobbies.setText("Please select at least on hobbies");

            flg = false;
        }else{
            tv_hobbies.setText("");
        }

        return flg;
    }
}
