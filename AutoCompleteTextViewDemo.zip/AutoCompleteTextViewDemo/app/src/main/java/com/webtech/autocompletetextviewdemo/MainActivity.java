package com.webtech.autocompletetextviewdemo;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    Context c;
    AutoCompleteTextView atv1;
    MultiAutoCompleteTextView atv2;

    String[] punjabisabji = {
            "Paneer Tika Masala",
            "Panner Kadai",
            "Paneer Handi",
            "Paneer Tufani",
            "Veg Kadai",
            "Veg Tufani"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        atv1 = findViewById(R.id.atv1);
        atv2 = findViewById(R.id.atv2);
        c = MainActivity.this;

        ArrayAdapter adapter = new ArrayAdapter(c,android.R.layout.simple_list_item_1,punjabisabji);
        atv1.setAdapter(adapter);
        atv1.setThreshold(1);

        atv2.setAdapter(adapter);
        atv2.setThreshold(1);
        atv2.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());


    }
}
